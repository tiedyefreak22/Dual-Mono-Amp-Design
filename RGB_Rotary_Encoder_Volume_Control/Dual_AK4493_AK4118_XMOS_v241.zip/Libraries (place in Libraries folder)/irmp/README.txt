IRMP - Infrared Multi Protocol Decoder
--------------------------------------

Version IRMP:  3.0.7 2017-02-17
Version IRSND: 3.0.6 2016-12-19

Documentation:
 
   http://www.mikrocontroller.net/articles/IRMP
   http://www.mikrocontroller.net/articles/IRMP_-_english

   http://www.mikrocontroller.net/articles/IRSND
   http://www.mikrocontroller.net/articles/IRSND_-_english
